<p align="center">

  <img src="https://assets.trivajs.com/header.jpg" >

</p>

## Getting Started

Designed to be accessable for Enterprise Enviornments, and additionally small-scale projects with a large scale goal, Triva is a Node HTTP Server Framework, with a focus on the infrastructure developers are looking for the most.

- Visit our [Getting Started]() guide to begin building today.
- Visit our [Extensions Overivew]() for additional resources & experience enhancing tools.

## Documentation

Visit [docs.trivajs.com]() for a complete overview of our documentation & guides.
